# Project Documentation

This is a sample project for demonstration purposes.

## Files
- config.json: Configuration settings
- data.txt: Sample data
